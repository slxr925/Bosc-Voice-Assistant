#!/usr/bin/python
# -*- coding: UTF-8 -*-
from model.diningRoom_test import get_dinningRoom